package com.example.capstone

interface ApiService {
}