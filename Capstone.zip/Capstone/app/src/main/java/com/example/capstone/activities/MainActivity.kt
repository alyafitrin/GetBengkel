package com.example.capstone.activities

class MainActivity {
}