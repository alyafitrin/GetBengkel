package com.example.capstone

class ApiConfig {
}